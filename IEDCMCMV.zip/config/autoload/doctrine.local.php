<?php

return array(
  'doctrine' => array(
    'connection' => array(
      'orm_default' => array(
        'driverClass' =>'Doctrine\DBAL\Driver\PDOMySql\Driver',
        'params' => array(
          'host'     => '10.0.0.249',
          'port'     => '3306',
          'user'     => 'iedcmcmv',
          'password' => '@$iedcmcmvq1w2e3r4#%',
          'dbname'   => 'iedcmcmv',
          'charset'  => 'utf8',
        )
      )
    ),
  )
);